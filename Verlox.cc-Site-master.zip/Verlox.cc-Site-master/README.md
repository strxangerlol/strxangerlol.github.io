## Intro
Heres my site, feel free to use and modify

## About
Was based off certain elements from <a href="https://github.com/Lumm1t/obnoxious.club">obnoxious.club</a> by Lumm1t, but decided that I wanted something a little original, so I "coded" (more skidded cause fuck html and css) this site

## Credits
* Cordae - Super [song]
* Marquee
* JQuery
